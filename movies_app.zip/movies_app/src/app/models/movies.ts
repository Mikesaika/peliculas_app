export interface movie{
    id?:number,
    title:string,
    genreId:number,
    releaseDate:Date,
    budget: number;
    rating:string,
    poster:String
    active:boolean
}