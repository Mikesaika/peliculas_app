export interface genre{
id?:number,
name:string,
activate:boolean
}