import { Component } from '@angular/core';
import { movie } from '../../../models/movies';
import { ServMoviesJson } from '../../../services/serv-movies-json';
import { genre } from '../../../models/genre';
import { Router } from '@angular/router';

@Component({
  selector: 'app-movie-crud',
  imports: [],
  templateUrl: './movie-crud.html',
  styleUrl: './movie-crud.css',
})
export class MovieCrud {
  movies:movie[]=[];
  genres:genre[]=[];
constructor(private miServicio:ServMoviesJson, private router:Router){
  this.loadMovie();
  this.loadGenres();
}
    loadMovie():void{
      this.miServicio.getMovies().subscribe(
        (data:movie[])=>{
          this.movies=data;
          console.log("Peliculas"+this.movies[0].title);
        }
      );
  
      }
    loadGenres():void{
      this.miServicio.getGenre().subscribe(
        (data:genre[])=>{
          this.genres=data;
          console.log("Genero"+this.genres[0].name);
        }
      );
      
      }
  
      getGenreName(genreId:number):string{
        const genre= this.genres.find((g)=> Number(g.id)===Number(genreId)
  
        );
        return genre ? genre?.name: "sin genero";
  
      }
      edit(movies:movie){

      }
      delete(movies:movie){
        const confirmado = confirm(`¿Está seguro de eliminar la pelicula?`);
        if(confirmado){
          this.miServicio.deleteMovie(movies.id!).subscribe(
            ()=>{
              alert("Eliminado exitosamente");
              this.loadMovie;
            }
          );
        }
      }
      search(busq:HTMLInputElement){
        let parametro=busq.value.toLowerCase();
        this.miServicio.searchMovies(parametro).subscribe(
          (datos:movie[])=>{
            this.movies=datos;//actualiza elarreglo de movies  con los datos que llegan del servicio

          }
        );

      }
      view(id:number| undefined){
        //navegar a otro componente
        //this.router.navigate([`/movie-view`]);
        this.router.navigate([`/movie-view`,id]);  

      }



}
